package nlp_data_structure;

public abstract class PartOfSpeech {
	public abstract String getType(); 
	public abstract String getContentsByObject();
}
