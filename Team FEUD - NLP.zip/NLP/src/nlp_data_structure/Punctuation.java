package nlp_data_structure;

public class Punctuation extends PartOfSpeech {

    @Override
    public String getType() {
        return "Punctuation";
    }

	@Override
	public String getContentsByObject() {
		return null;
	}
}
